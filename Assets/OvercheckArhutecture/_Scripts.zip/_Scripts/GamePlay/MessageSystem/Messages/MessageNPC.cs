﻿public class MessageNPC : Message
{
    public override void Invoke()
    {
        
    }
}