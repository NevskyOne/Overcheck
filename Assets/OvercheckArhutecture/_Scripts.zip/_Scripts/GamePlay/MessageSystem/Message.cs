﻿using UnityEngine;

public abstract class Message : ScriptableObject
{
    public abstract void Invoke();
}