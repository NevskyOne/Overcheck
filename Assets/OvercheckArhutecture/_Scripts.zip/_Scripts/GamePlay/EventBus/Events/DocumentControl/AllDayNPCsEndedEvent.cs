﻿public class AllDayNPCsEndedEvent
{
}