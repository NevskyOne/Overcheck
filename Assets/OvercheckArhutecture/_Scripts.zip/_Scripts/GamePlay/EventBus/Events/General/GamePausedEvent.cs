﻿public class GamePausedEvent
{
}