﻿public class AutoSaveEvent
{
}