﻿using Zenject;

public class BindingsInstaller : MonoInstaller
{
    public override void InstallBindings()
    {
        Container.BindInterfacesTo<JsonSaver>().AsSingle();

        Container.Bind<EventBus>().AsSingle();
        Container.Bind<NPCDataBaseService>().AsSingle(); 
    }
}